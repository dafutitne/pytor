#pragma once
#include <cuda.h>
#include <cstdlib>
#include <cstring>

// Optional recovered assembly backend. The module is assembled from readable
// .cuasm source by scripts/build_qtc_asm.py; provenance remains explicit.
class QTCScanBackend {
 bool enabled=false,used=false,have_job=false;std::string backend_name="independent-cuda";
 CUmodule module=nullptr;CUfunction function=nullptr;CUdeviceptr job=0;
 uint32_t *original=nullptr,*hits,*total;
 Prepared last{};uint32_t start=0,count=0;unsigned block=128,worker_block=256;int maximum_threads=1024;
 static void dc(CUresult code){if(code!=CUDA_SUCCESS){const char *message=nullptr;cuGetErrorString(code,&message);throw std::runtime_error(message?message:"CUDA driver error");}}
 void validate_native() {
  uint32_t words[24]={};const unsigned count=4096;const uint64_t threshold=(uint64_t(1)<<58)-1;Prepared prepared=::prepare(words,0,threshold);prepare_job(prepared);reset();uint32_t first=0,work=count;unsigned threads=std::min(worker_block,unsigned(maximum_threads));CUdeviceptr output=reinterpret_cast<CUdeviceptr>(original);void *args[]={&output,&first,&work};dc(cuLaunchKernel(function,(work+threads-1)/threads,1,1,threads,1,1,0,nullptr,args,nullptr));ck(cudaDeviceSynchronize());
  uint32_t found=0;ck(cudaMemcpy(&found,original+255,4,cudaMemcpyDeviceToHost));if(found>252)throw std::runtime_error("native QTC backend selfcheck overflow");
  std::vector<uint32_t> actual(found),expected;ck(cudaMemcpy(actual.data(),original,found*4,cudaMemcpyDeviceToHost));
  for(unsigned counter=0;counter<count;counter++){uint32_t input[24];unsigned char digest[64];qtc::map_nonce(words,counter,input);qtc::hash_words(input,digest);if(qtc::prefix(digest)<=threshold)expected.push_back(counter);}
  std::sort(actual.begin(),actual.end());if(actual!=expected)throw std::runtime_error("native QTC backend failed independent CPU candidate selfcheck");have_job=false;
 }
public:
 QTCScanBackend(uint32_t *h,uint32_t *t):hits(h),total(t) {
  const char *path=std::getenv("KAETECH_QTC_ASM");if(!path||!*path)path=std::getenv("QPMINER_QTC_ASM");if(!path||!*path)return;
  dc(cuInit(0));dc(cuModuleLoad(&module,path));dc(cuModuleGetFunction(&function,module,"_kernel_quantus_0"));dc(cuFuncGetAttribute(&maximum_threads,CU_FUNC_ATTRIBUTE_MAX_THREADS_PER_BLOCK,function));
  size_t size=0;dc(cuModuleGetGlobal(&job,&size,module,"srb_quantus_line_work"));if(size!=120)throw std::runtime_error("recovered kernel job ABI mismatch");
  ck(cudaMalloc(&original,1024));int major=0,minor=0;dc(cuDeviceComputeCapability(&major,&minor,0));backend_name="recovered-sass-sm"+std::to_string(major*10+minor);enabled=true;
  // SM70 and paired Tesla T4 trials favor 512; other GPU defaults stay unchanged.
  char device_name[256]{};dc(cuDeviceGetName(device_name,sizeof(device_name),0));
  if(major==7&&(minor==0||(minor==5&&std::strstr(device_name," T4"))))worker_block=512;
  // Recovered Pascal uses CTAID.X<<10, so this is a correctness constraint.
  if(major==6&&(minor==1||minor==2)||major==5&&minor==2&&std::strstr(path,"qtc-ported-sm52")){
   if(maximum_threads<1024)throw std::runtime_error("SM61 QTC requires block1024");
   worker_block=1024;
   if(major==5)backend_name="ported-sass-sm52";
  }
  worker_block=std::min(worker_block,unsigned(maximum_threads));
  if(std::getenv("KAETECH_QTC_AUTOMATIC"))validate_native();
 }
 ~QTCScanBackend(){if(original)cudaFree(original);if(module)cuModuleUnload(module);}
 QTCScanBackend(const QTCScanBackend&)=delete;
 const char *name()const{return backend_name.c_str();}
 unsigned worker_threads()const{return worker_block;}
 void prepare_job(const Prepared &p) {
  if(enabled&&(!have_job||std::memcmp(&p,&last,sizeof(p)))){dc(cuMemcpyHtoD(job,&p,sizeof(p)));last=p;have_job=true;}
  else last=p;
 }
 void reset(){if(enabled)ck(cudaMemset(original+255,0,4));else ck(cudaMemset(total,0,4));}
 void launch(uint32_t first,uint32_t n,unsigned threads) {
  start=first;count=n;block=threads;
  // Large targets can fill the original 252-slot result buffer. Use the
  // independently written kernel for these diagnostic/all-hit workloads.
  auto expected=((static_cast<unsigned __int128>(last.threshold)+1)*count)>>64;
  used=enabled&&expected<128;
  if(used&&worker_block==1024&&block!=1024)throw std::runtime_error("Recovered SM61 QTC uses fixed block1024; other blocks skip nonce ranges");
  if(used) {
   block=std::min(block,unsigned(maximum_threads));
   CUdeviceptr output=reinterpret_cast<CUdeviceptr>(original);void *args[]={&output,&start,&count};
   dc(cuLaunchKernel(function,(count+block-1)/block,1,1,block,1,1,0,nullptr,args,nullptr));
  }else {if(enabled)ck(cudaMemset(total,0,4));unsigned portable_block=worker_block==1024?std::min(block,256U):block;scan_kernel<<<(count+portable_block-1)/portable_block,portable_block>>>(last,start,count,hits,total);ck(cudaGetLastError());}
 }
 bool collect(std::vector<uint32_t> &candidates) {
  // Read the native result directly. Avoid two D2D copies and a duplicate
  // synchronous count read on every network-worker dispatch.
  uint32_t size=0;bool recovered=false;const uint32_t *source=used?original:hits;
  ck(cudaMemcpy(&size,used?original+255:total,4,cudaMemcpyDeviceToHost));
  if(used&&size>=252){
   ck(cudaMemset(total,0,4));unsigned portable_block=worker_block==1024?std::min(block,256U):block;scan_kernel<<<(count+portable_block-1)/portable_block,portable_block>>>(last,start,count,hits,total);ck(cudaGetLastError());ck(cudaDeviceSynchronize());
   ck(cudaMemcpy(&size,total,4,cudaMemcpyDeviceToHost));source=hits;recovered=true;
  }
  if(size>count)throw std::runtime_error("QTC candidate overflow");
  candidates.resize(size);if(size)ck(cudaMemcpy(candidates.data(),source,size*4,cudaMemcpyDeviceToHost));return recovered;
 }
};
