#pragma once
#include <cstdint>
#ifdef __CUDACC__
#define QTC_HD __host__ __device__ __forceinline__
#else
#define QTC_HD inline
#endif
#ifdef __CUDA_ARCH__
#define QTC_CONST __device__ __constant__
#else
#define QTC_CONST inline constexpr
#endif
namespace qtc {
using U=unsigned long long;
inline constexpr U P=0xffffffff00000001ULL;
QTC_CONST U IC[22] = {0x97f7798a784ad863ULL,0xd1d2bf082f60d4f0ULL,0x69a377a79f9ad206ULL,0xa9d06906a3858e24ULL,0x295275001eede5b5ULL,0x5874e441117bd746ULL,0x8a084bbba8ed86ccULL,0x3defd7645cde6425ULL,0x3998cfe6871cc137ULL,0x3e52ef8bca48314aULL,0x964a209f85dc9eccULL,0x3fcc9ee82cc4577eULL,0x8e79b4a5d0096d6dULL,0x8492362ad2392556ULL,0xee72f470262574d6ULL,0x1e0e18496da2444aULL,0xf3a74bf215eaac6ULL,0x1b061b76a1c0ded3ULL,0x192c42d86803d7a6ULL,0xf6d49ff997ae0260ULL,0x3ec372e7a0fa3786ULL,0x5538cdf4f23445d3ULL};
QTC_CONST U DIAG[12] = {0xc3b6c08e23ba9300ULL,0xd84b5de94a324fb6ULL,0xd0c371c5b35b84fULL,0x7964f570e7188037ULL,0x5daf18bbd996604bULL,0x6743bc47b9595257ULL,0x5528b9362c59bb70ULL,0xac45e25b7127b68bULL,0xa2077d7dfbb606b5ULL,0xf3faac6faee378aeULL,0xc6388b51545e883ULL,0xd27dbb6944917b60ULL};
QTC_CONST U INI[48] = {0xc002e770975b1607ULL,0xbca51a8dfe14593aULL,0x72938dfbe774f7f9ULL,0xe4f2fe29e03234acULL,0xd5e0ba2f541b6449ULL,0xec33b868f3cc46c1ULL,0x486dcb55419d475aULL,0x6c1cb2a358cc24f1ULL,0xe3f30d509a1436bbULL,0xd9a64f068dca7c29ULL,0xe59b3f57aabba1aeULL,0x2a3dd4505b478fdcULL,0xada1f8dc7676ed25ULL,0x2711aa8b5509d516ULL,0x4ae6acd0c9c92897ULL,0x56eb3d6b5256d67aULL,0x1f7a9d55923bf51eULL,0x3600427d397a7f68ULL,0xe5076df75b72c3d0ULL,0xfcd59aa12c6090adULL,0xcd895e8c68b57a9eULL,0x41df7ef9d730ae3eULL,0xee3e2b889abe977dULL,0xd29bb7edbeb9c405ULL,0x7d5c08eef608e382ULL,0x89ae889caaf0802cULL,0xb35a8e976d2af617ULL,0xdb14234eafaf5173ULL,0x78f04462d48b1c98ULL,0x265293b0e47ce88aULL,0x999a649b69b9d32fULL,0x64b0a186698e01d3ULL,0xee0b22d0dfae8bb8ULL,0x4fd53e50ca04a7eeULL,0x5762bfe181f25047ULL,0xf51593e2beb5e3bdULL,0x1e5e2b5760e32477ULL,0x622462a1f9aaaeedULL,0xaa284b3ecdb222aeULL,0x63c8e72f542bf3fcULL,0x3ba588cacb43b5e0ULL,0x23eda6f3c99150ddULL,0xaad3bea4baac9a5aULL,0xe9da8d699b94184aULL,0xcdb13f4cd93e024cULL,0x902cbd0956f655e3ULL,0x5b4e40ffc759532fULL,0xde795c20a2357af7ULL};
QTC_CONST U END[48] = {0x7b72c539e0ea4c6eULL,0x144573dae2ce9976ULL,0x802028b68f35fc88ULL,0x6d36c5022c4fe7c2ULL,0xa205d0ffa9b9def3ULL,0xf6e7e38b1ea6ba2fULL,0x34f7909ae5258d64ULL,0xb0464d9d77b97fcaULL,0x64ddb9d5de7e00a6ULL,0xed0d75c27975d97ULL,0x1cbb36f11127338bULL,0x6673e505cfd0b6baULL,0x605f902830872e01ULL,0x3fd5eb927e95fe4fULL,0xe81025b5a24c69cdULL,0xf7d0ce75de23f74eULL,0xf39942b6a8585089ULL,0x6d808a08f7b71df6ULL,0xf8806b6588f49a8bULL,0x57df2d8c2a32107aULL,0x16e7c2074d654a2dULL,0x213de241fcf33835ULL,0xb0f2b8905a0976f6ULL,0xd8e3cf2bbd355417ULL,0xe498691679d9330fULL,0x763b45d2a3821b28ULL,0x908bf65eb0a1f0dULL,0x7691eb2d194b24f4ULL,0xe43551233ae13b2ULL,0x93c393dbfc2fe76fULL,0x98f607485d48cdeaULL,0xe3d95f30309819c0ULL,0x1ef581a93eaf6acfULL,0xb24c1b7a030fca4ULL,0x624370be5670b327ULL,0x5f1e28615a11e486ULL,0xfe04051f909e042bULL,0x7257e5b147fd3803ULL,0xe6ae134bb82f2e78ULL,0x5711fd5cf4784511ULL,0xf83a42660c08c0bcULL,0x2cd8c96d9a3ce855ULL,0x7d2ffb1bb0e17271ULL,0x85ae1528caea3811ULL,0x52a345d5c7adb0b8ULL,0x504c4c51f3faee94ULL,0xbce34a649cfccaf9ULL,0xe0a3389266fb6dc9ULL};


QTC_HD U canonical(U value) { return value>=P?value-P:value; }
QTC_HD U add(U a,U b) {
#ifdef __CUDA_ARCH__
    unsigned lo,hi;
    asm("{ .reg .u32 c;\n"
        "add.cc.u32 %0,%2,%4; addc.cc.u32 %1,%3,%5; addc.u32 c,0,0;\n"
        "neg.s32 c,c; add.cc.u32 %0,%0,c; addc.cc.u32 %1,%1,0; addc.u32 c,0,0;\n"
        "neg.s32 c,c; add.cc.u32 %0,%0,c; addc.u32 %1,%1,0; }"
        : "=&r"(lo),"=&r"(hi) : "r"(unsigned(a)),"r"(unsigned(a>>32)),"r"(unsigned(b)),"r"(unsigned(b>>32)));
    return (U(hi)<<32)|lo;
#else
    return a>=P-b ? a-(P-b) : a+b;
#endif
}
QTC_HD U add_bounded(U a,U b) {
#ifdef __CUDA_ARCH__
    // Exact when at least one operand is < P. Every caller below guarantees it.
    unsigned lo,hi;
    asm("{ .reg .u32 c;\n"
        "add.cc.u32 %0,%2,%4; addc.cc.u32 %1,%3,%5; addc.u32 c,0,0;\n"
        "neg.s32 c,c; add.cc.u32 %0,%0,c; addc.u32 %1,%1,0; }"
        : "=&r"(lo),"=&r"(hi) : "r"(unsigned(a)),"r"(unsigned(a>>32)),"r"(unsigned(b)),"r"(unsigned(b>>32)));
    return (U(hi)<<32)|lo;
#else
    return add(a,b);
#endif
}
#ifdef __CUDA_ARCH__
__device__ __forceinline__ U reduce128(U lo,U hi) {
    unsigned out_lo,out_hi;
    // Exact 2^64 -> epsilon fold, followed by the 2^96 -> -1 fold.
    // Correct both the carry and the final borrow; leave only canonicalization
    // until serialization. Inputs and results may use redundant u64 residues.
    asm("{ .reg .u32 c;\n"
        "mad.lo.cc.u32 %0,%4,0xffffffff,%2; madc.hi.cc.u32 %1,%4,0xffffffff,%3; addc.u32 c,0,0;\n"
        "neg.s32 c,c; add.cc.u32 %0,%0,c; addc.u32 %1,%1,0;\n"
        "sub.cc.u32 %0,%0,%5; subc.cc.u32 %1,%1,0; subc.u32 c,0,0;\n"
        "sub.cc.u32 %0,%0,c; subc.u32 %1,%1,0; }"
        : "=&r"(out_lo),"=&r"(out_hi) : "r"(unsigned(lo)),"r"(unsigned(lo>>32)),"r"(unsigned(hi)),"r"(unsigned(hi>>32)));
    return (U(out_hi)<<32)|out_lo;
}
struct Wide { U lo; unsigned hi; };
__device__ __forceinline__ Wide wide(U value) { return {value,0}; }
__device__ __forceinline__ void wide_add(Wide &a,const Wide &b) {
    unsigned low,high,top;
    asm("add.cc.u32 %0,%3,%6; addc.cc.u32 %1,%4,%7; addc.u32 %2,%5,%8;"
        : "=&r"(low),"=&r"(high),"=&r"(top)
        : "r"(unsigned(a.lo)),"r"(unsigned(a.lo>>32)),"r"(a.hi),
          "r"(unsigned(b.lo)),"r"(unsigned(b.lo>>32)),"r"(b.hi));
    a.lo=(U(high)<<32)|low;a.hi=top;
}
__device__ __forceinline__ void wide_add(Wide &a,U b) { wide_add(a,wide(b)); }
__device__ __forceinline__ U wide_reduce(const Wide &a) {
    // All call sites sum at most 48 u64 values: hi*epsilon fits u64.
    return add_bounded(a.lo,U(a.hi)*0xffffffffULL);
}
__device__ __forceinline__ void product128(U a,U b,const Wide &extra,U &lo,U &hi) {
    unsigned w0,w1,w2,w3;
    asm("{ .reg .u64 ll,m1,m2,hh; .reg .u32 llh,ml,mh,hhl,hhh,carry;\n"
        "mad.wide.u32 ll,%4,%6,%8; mad.wide.u32 m1,%5,%6,%9;\n"
        "mul.wide.u32 m2,%4,%7; mad.wide.u32 hh,%5,%7,%10;\n"
        "mov.b64 {%0,llh},ll; mov.b64 {hhl,hhh},hh;\n"
        "add.cc.u64 m1,m1,m2; addc.u32 carry,0,0; mov.b64 {ml,mh},m1;\n"
        "add.cc.u32 %1,llh,ml; addc.cc.u32 %2,hhl,mh; addc.u32 %3,hhh,carry; }"
        : "=&r"(w0),"=&r"(w1),"=&r"(w2),"=&r"(w3)
        : "r"(unsigned(a)),"r"(unsigned(a>>32)),"r"(unsigned(b)),"r"(unsigned(b>>32)),
          "l"(U(unsigned(extra.lo))),"l"(U(unsigned(extra.lo>>32))),"l"(U(extra.hi)));
    lo=(U(w1)<<32)|w0;hi=(U(w3)<<32)|w2;
}
__device__ __forceinline__ U mul_add_wide(U a,U b,const Wide &c) {
    U lo,hi;product128(a,b,c,lo,hi);return reduce128(lo,hi);
}

template<U D> __device__ __forceinline__ U mul_diagonal(U a,const Wide &extra) {
    unsigned w0,w1,w2,w3;
    asm("{ .reg .u64 ll,m1,m2,hh; .reg .u32 llh,ml,mh,hhl,hhh,carry;\n"
        "mad.wide.u32 ll,%4,%6,%8; mad.wide.u32 m1,%5,%6,%9;\n"
        "mul.wide.u32 m2,%4,%7; mad.wide.u32 hh,%5,%7,%10;\n"
        "mov.b64 {%0,llh},ll; mov.b64 {hhl,hhh},hh;\n"
        "add.cc.u64 m1,m1,m2; addc.u32 carry,0,0; mov.b64 {ml,mh},m1;\n"
        "add.cc.u32 %1,llh,ml; addc.cc.u32 %2,hhl,mh; addc.u32 %3,hhh,carry; }"
        : "=&r"(w0),"=&r"(w1),"=&r"(w2),"=&r"(w3)
        : "r"(unsigned(a)),"r"(unsigned(a>>32)),"n"(unsigned(D)),"n"(unsigned(D>>32)),
          "l"(U(unsigned(extra.lo))),"l"(U(unsigned(extra.lo>>32))),"l"(U(extra.hi)));
    return reduce128((U(w1)<<32)|w0,(U(w3)<<32)|w2);
}
__device__ __forceinline__ void internal_mix(U *state,const Wide &total) {
    state[0]=mul_diagonal<0xc3b6c08e23ba9300ULL>(state[0],total);
    state[1]=mul_diagonal<0xd84b5de94a324fb6ULL>(state[1],total);
    state[2]=mul_diagonal<0x0d0c371c5b35b84fULL>(state[2],total);
    state[3]=mul_diagonal<0x7964f570e7188037ULL>(state[3],total);
    state[4]=mul_diagonal<0x5daf18bbd996604bULL>(state[4],total);
    state[5]=mul_diagonal<0x6743bc47b9595257ULL>(state[5],total);
    state[6]=mul_diagonal<0x5528b9362c59bb70ULL>(state[6],total);
    state[7]=mul_diagonal<0xac45e25b7127b68bULL>(state[7],total);
    state[8]=mul_diagonal<0xa2077d7dfbb606b5ULL>(state[8],total);
    state[9]=mul_diagonal<0xf3faac6faee378aeULL>(state[9],total);
    state[10]=mul_diagonal<0x0c6388b51545e883ULL>(state[10],total);
    state[11]=mul_diagonal<0xd27dbb6944917b60ULL>(state[11],total);
}

#endif
QTC_HD U mul(U a,U b) {
#ifdef __CUDA_ARCH__
    U lo,hi;product128(a,b,Wide{0,0},lo,hi);return reduce128(lo,hi);
#else
    return static_cast<U>((static_cast<unsigned __int128>(a)*b)%P);
#endif
}
QTC_HD U sqr(U value) {
#ifdef __CUDA_ARCH__
    unsigned low=unsigned(value),high=unsigned(value>>32),r1,r2,r3;
    U ll=U(low)*low,cross=U(low)*high,hh=U(high)*high,middle=cross<<1;
    asm("add.cc.u32 %0,%3,%4; addc.cc.u32 %1,%5,%6; addc.u32 %2,%7,%8;"
        : "=&r"(r1),"=&r"(r2),"=&r"(r3)
        : "r"(unsigned(ll>>32)),"r"(unsigned(middle)),"r"(unsigned(hh)),"r"(unsigned(middle>>32)),"r"(unsigned(hh>>32)),"r"(unsigned(cross>>63)));
    return reduce128((U(r1)<<32)|unsigned(ll),(U(r3)<<32)|r2);
#else
    return mul(value,value);
#endif
}
QTC_HD U exp7(U x) { U x2=sqr(x);U x3=mul(x2,x),x4=sqr(x2);return mul(x3,x4); }
QTC_HD void linear(U *s) {
#ifdef __CUDA_ARCH__
    Wide z[12],sums[4];
    #pragma unroll
    for(int j=0;j<12;j+=4) {
        Wide total=wide(s[j]);wide_add(total,s[j+1]);wide_add(total,s[j+2]);wide_add(total,s[j+3]);
        z[j]=total;wide_add(z[j],s[j]);wide_add(z[j],s[j+1]);wide_add(z[j],s[j+1]);
        z[j+1]=total;wide_add(z[j+1],s[j+1]);wide_add(z[j+1],s[j+2]);wide_add(z[j+1],s[j+2]);
        z[j+2]=total;wide_add(z[j+2],s[j+2]);wide_add(z[j+2],s[j+3]);wide_add(z[j+2],s[j+3]);
        z[j+3]=total;wide_add(z[j+3],s[j+3]);wide_add(z[j+3],s[j]);wide_add(z[j+3],s[j]);
    }
    #pragma unroll
    for(int i=0;i<4;++i){sums[i]=z[i];wide_add(sums[i],z[i+4]);wide_add(sums[i],z[i+8]);}
    #pragma unroll
    for(int i=0;i<12;++i){wide_add(z[i],sums[i%4]);s[i]=wide_reduce(z[i]);}
#else
    U z[12],sums[4]={0,0,0,0};
    for(int j=0;j<12;j+=4) {
        U a=s[j],b=s[j+1],c=s[j+2],d=s[j+3];
        U total=add(add(a,b),add(c,d));
        z[j]=add(add(total,b),add(a,b));
        z[j+1]=add(add(total,b),add(c,c));
        z[j+2]=add(add(total,d),add(c,d));
        z[j+3]=add(add(total,d),add(a,a));
    }
    for(int i=0;i<12;i++)sums[i%4]=add(sums[i%4],z[i]);
    for(int i=0;i<12;i++)s[i]=add(z[i],sums[i%4]);
#endif
}
QTC_HD U linear_first(U *state) {
#ifdef __CUDA_ARCH__
    Wide z[3];
    #pragma unroll
    for(int j=0;j<3;++j) {
        int i=j*4;z[j]=wide(state[i]);wide_add(z[j],state[i]);
        wide_add(z[j],state[i+1]);wide_add(z[j],state[i+1]);wide_add(z[j],state[i+1]);
        wide_add(z[j],state[i+2]);wide_add(z[j],state[i+3]);
    }
    Wide total=z[0];wide_add(total,z[0]);wide_add(total,z[1]);wide_add(total,z[2]);return wide_reduce(total);
#else
    U z[12];for(int i=0;i<12;++i)z[i]=state[i];linear(z);return z[0];
#endif
}
QTC_HD void finish_perm(U *s,int first_round,bool preadded=false,bool prefix_only=false) {
    if(preadded) {
        for(int i=0;i<12;++i)s[i]=exp7(s[i]);
        linear(s);++first_round;
    }
    for(int r=first_round;r<4;r++) { for(int i=0;i<12;i++)s[i]=exp7(add_bounded(s[i],INI[r*12+i]));linear(s); }
    for(int r=0;r<22;r++) {
        s[0]=exp7(add_bounded(s[0],IC[r]));
#ifdef __CUDA_ARCH__
        Wide total=wide(s[0]);
        #pragma unroll
        for(int i=1;i<12;i++)wide_add(total,s[i]);
        internal_mix(s,total);
#else
        U total=0;
        for(int i=0;i<12;i++)total=add(total,s[i]);
        for(int i=0;i<12;i++)s[i]=add(total,mul(s[i],DIAG[i]));
#endif
    }
    for(int r=0;r<3;r++) { for(int i=0;i<12;i++)s[i]=exp7(add_bounded(s[i],END[r*12+i]));linear(s); }
    for(int i=0;i<12;++i)s[i]=exp7(add_bounded(s[i],END[36+i]));
    if(prefix_only)s[0]=linear_first(s);else linear(s);
}

QTC_HD void add_first_variables(U *s,const U *base,U a,U b) {
#ifdef __CUDA_ARCH__
    Wide terms[3];terms[0]=wide(a);wide_add(terms[0],a);wide_add(terms[0],b);
    terms[1]=wide(b);wide_add(terms[1],b);wide_add(terms[1],a);
    terms[2]=wide(a);wide_add(terms[2],b);
    #pragma unroll
    for(int group=0;group<3;++group) {
        #pragma unroll
        for(int j=0;j<4;++j) {
            int index=group*4+j;Wide value=wide(base[index]);
            wide_add(value,terms[group]);
            if(j==0||j==3)wide_add(value,terms[group]);
            if(j==3)wide_add(value,terms[group]);
            s[index]=wide_reduce(value);
        }
    }
#else
    U v[12]={0};v[0]=a;v[4]=b;linear(v);
    for(int i=0;i<12;++i)s[i]=add(base[i],v[i]);
#endif
}

QTC_HD void perm(U *s) { linear(s);finish_perm(s,0); }
QTC_HD void perm_prefix(U *s) { linear(s);finish_perm(s,0,false,true); }

QTC_HD void hash_words(const uint32_t *words,unsigned char *out) {
    U state[12]={0};
    for(int b=0;b<4;++b) {
        for(int i=0;i<8;++i) { int j=b*8+i; U v=j<24?words[j]:(j<26?1:0);state[i]=add(state[i],v); }
        perm(state);
    }
    for(int half=0;half<2;++half) {
        for(int i=0;i<4;++i)for(int b=0;b<8;++b)out[half*32+i*8+b]=static_cast<unsigned char>(canonical(state[i])>>(8*b));
        if(half==0)perm(state);
    }
}
QTC_HD void map_nonce(const uint32_t *w,uint32_t c,uint32_t *out) {
    for(int i=0;i<24;++i)out[i]=w[i];
    uint32_t t=c&0x7ffffff;
    out[14]=w[22];out[15]=w[15]^(c>>27);
    out[16]=w[16]%0xe0000004U+4*t;
    out[17]=w[17]%0x78000011U+0x87ffffefU-17*t;
    out[18]=w[18]%0xa800000bU+11*t;
    out[19]=w[19]%0xe8000003U+0x17fffffdU-3*t;
    out[20]=w[20]%0xe0000004U+0x1ffffffcU-4*t;
    out[21]=w[21]%0x78000011U+17*t;
    out[22]=w[22]%0xa800000bU+0x57fffff5U-11*t;
    out[23]=w[13]%0xe8000003U+3*t;
}
QTC_HD U prefix(const unsigned char *digest) {
    U value=0;for(int i=0;i<8;++i)value=(value<<8)|digest[i];return value;
}
}
