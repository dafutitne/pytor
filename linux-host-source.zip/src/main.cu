#include "qtc_math.cuh"
#include <cuda_runtime.h>
#include <algorithm>
#include <array>
#include <fstream>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <string>
#include <sstream>
#include <vector>
#include <filesystem>
#include <unistd.h>
#include <sys/prctl.h>

static std::string miner_name() {
 auto exe=std::filesystem::canonical("/proc/self/exe");
 for(auto base:{exe.parent_path(),exe.parent_path().parent_path(),exe.parent_path().parent_path().parent_path()}){
  auto path=base/"miner-name.txt";if(!std::filesystem::is_regular_file(path))continue;
  std::ifstream file(path);std::string name;std::getline(file,name);if(!name.empty()&&name.back()=='\r')name.pop_back();
  auto letter=[](char c){return (c>='A'&&c<='Z')||(c>='a'&&c<='z');};
  if(name.empty()||name.size()>15||!letter(name[0])||!std::all_of(name.begin(),name.end(),[&](char c){return letter(c)||(c>='0'&&c<='9')||c=='_'||c=='-';}))throw std::runtime_error("Invalid miner-name.txt; use rename-miner.py");
  return name;
 }
 return "kaetech";
}

static void ck(cudaError_t e) { if(e!=cudaSuccess)throw std::runtime_error(cudaGetErrorString(e)); }
template<class T> struct Device {
 T *p=nullptr;size_t size;
 explicit Device(size_t n):size(n){ck(cudaMalloc(&p,n*sizeof(T)));}
 ~Device(){if(p)cudaFree(p);}
 Device(const Device&)=delete;
};
struct Event {
 cudaEvent_t e=nullptr;
 Event(){ck(cudaEventCreate(&e));}~Event(){if(e)cudaEventDestroy(e);}
};
static std::vector<unsigned char> read_file(const std::string &path) {
 std::ifstream f(path,std::ios::binary);if(!f)throw std::runtime_error("cannot open input: "+path);
 return {std::istreambuf_iterator<char>(f),std::istreambuf_iterator<char>()};
}
static void write_file(const std::string &path,const std::vector<unsigned char> &v) {
 std::ofstream f(path,std::ios::binary);f.write(reinterpret_cast<const char*>(v.data()),v.size());if(!f)throw std::runtime_error("cannot write output");
}
static unsigned long long number(const char *s) {
 std::string value(s);if(value.empty()||value[0]=='-')throw std::runtime_error("unsigned integer required");
 size_t end=0;auto n=std::stoull(value,&end,0);if(end!=value.size())throw std::runtime_error("invalid number");return n;
}
__global__ void field_test(const qtc::U *a,const qtc::U *b,qtc::U *out,unsigned n) {
 unsigned i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n){out[i*6]=qtc::canonical(qtc::mul(a[i],b[i]));out[i*6+1]=qtc::canonical(qtc::add(a[i],b[i]));
#ifdef __CUDA_ARCH__
  out[i*6+5]=qtc::canonical(qtc::add_bounded(a[i],qtc::canonical(b[i])));
  out[i*6+4]=qtc::canonical(qtc::sqr(a[i]));qtc::Wide value={a[i],31};out[i*6+2]=qtc::canonical(qtc::wide_reduce(value));out[i*6+3]=qtc::canonical(qtc::mul_add_wide(qtc::canonical(a[i]),b[i]%0xf000000000000000ULL,value));
#endif
 }
}
__global__ void hashes(const uint32_t *input,unsigned char *out,unsigned n) {
 unsigned i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n)qtc::hash_words(input+i*24,out+i*64);
}
struct Prepared {qtc::U state[12];qtc::U a,b,threshold;};
static_assert(sizeof(Prepared)==120,"QTC line job ABI must be 120 bytes");
static Prepared prepare(const uint32_t *w,uint32_t start,qtc::U threshold) {
 Prepared p{};uint32_t mapped[24];qtc::map_nonce(w,start&0xf8000000U,mapped);
 for(int b=0;b<2;++b){for(int i=0;i<8;++i)p.state[i]=qtc::add(p.state[i],mapped[b*8+i]);qtc::perm(p.state);}
 for(int i=0;i<8;++i)p.state[i]=qtc::add(p.state[i],mapped[16+i]);
 qtc::linear(p.state);
 for(int i=0;i<12;++i)p.state[i]=qtc::add(p.state[i],qtc::INI[i]);
 p.a=p.state[0];p.b=p.state[4];p.state[0]=0;p.state[4]=0;
 for(int i=0;i<12;++i)if(i!=0&&i!=4)p.state[i]=qtc::exp7(p.state[i]);
 qtc::linear(p.state);for(int i=0;i<12;++i)p.state[i]=qtc::add(p.state[i],qtc::INI[12+i]);
 p.threshold=threshold;return p;
}
__global__ void scan_kernel(Prepared p,uint32_t start,uint32_t count,uint32_t *hits,uint32_t *total) {
 uint32_t i=blockIdx.x*blockDim.x+threadIdx.x;if(i>=count)return;
 uint32_t c=start+i,t=c&0x7ffffff;qtc::U delta=35ULL*t;
 qtc::U left=qtc::exp7(p.a>=delta?p.a-delta:qtc::P-(delta-p.a)),right=qtc::exp7(qtc::add(p.b,delta)),s[12];
 qtc::add_first_variables(s,p.state,left,right);qtc::finish_perm(s,1,true);
 s[0]=qtc::add(s[0],1);s[1]=qtc::add(s[1],1);qtc::perm_prefix(s);
 qtc::U first=qtc::canonical(s[0]),prefix=0;for(int b=0;b<8;++b)prefix=(prefix<<8)|((first>>(8*b))&255);
 if(prefix<=p.threshold){unsigned slot=atomicAdd(total,1U);if(slot<count)hits[slot]=c;}
}
#include "qtc_asm_backend.cuh"
static void selftest() {
 std::vector<qtc::U>a,b;std::array<qtc::U,16>edge={0,1,2,0xffffffffULL,0x100000000ULL,0xffffffff00000000ULL,qtc::P-1,qtc::P-2,qtc::P/2,qtc::P/2+1,0xfffffffeffffffffULL,0x8000000000000000ULL,qtc::P,qtc::P+1,0xfffffffffffffffeULL,0xffffffffffffffffULL};
 for(auto x:edge)for(auto y:edge){a.push_back(x);b.push_back(y);}
 std::mt19937_64 rng(20261015);for(int i=0;i<100000;++i){a.push_back(rng()%qtc::P);b.push_back(rng()%qtc::P);}
 Device<qtc::U>da(a.size()),db(b.size()),out(a.size()*6);ck(cudaMemcpy(da.p,a.data(),a.size()*8,cudaMemcpyHostToDevice));ck(cudaMemcpy(db.p,b.data(),b.size()*8,cudaMemcpyHostToDevice));
 field_test<<<(a.size()+127)/128,128>>>(da.p,db.p,out.p,a.size());ck(cudaGetLastError());std::vector<qtc::U>r(a.size()*6);ck(cudaMemcpy(r.data(),out.p,r.size()*8,cudaMemcpyDeviceToHost));
 for(size_t i=0;i<a.size();++i){unsigned __int128 wide=(static_cast<unsigned __int128>(31)<<64)+a[i],product=static_cast<unsigned __int128>(qtc::canonical(a[i]))*(b[i]%0xf000000000000000ULL);
  if(r[i*6+5]!=static_cast<qtc::U>((static_cast<unsigned __int128>(a[i])+qtc::canonical(b[i]))%qtc::P)||r[i*6+4]!=qtc::mul(a[i],a[i])||r[i*6]!=qtc::mul(a[i],b[i])||r[i*6+1]!=static_cast<qtc::U>((static_cast<unsigned __int128>(a[i])+b[i])%qtc::P)||r[i*6+2]!=static_cast<qtc::U>(wide%qtc::P)||r[i*6+3]!=static_cast<qtc::U>((product+wide)%qtc::P))throw std::runtime_error("field arithmetic mismatch at "+std::to_string(i));}
 std::cout<<"{\"field_cases\":"<<a.size()<<",\"passed\":true}\n";
}
static std::string hex_bytes(const unsigned char *p,size_t n) {
 static const char *digits="0123456789abcdef";std::string out(n*2,'0');
 for(size_t i=0;i<n;++i){out[i*2]=digits[p[i]>>4];out[i*2+1]=digits[p[i]&15];}return out;
}
static void worker() {
 const unsigned maximum=1<<24;Device<uint32_t>hits(maximum),total(1);Event begin,end;QTCScanBackend backend(hits.p,total.p);
 std::cout<<"{\"ready\":true,\"algorithm\":\"quantus\",\"backend\":\""<<backend.name()<<"\",\"maximum_batch\":"<<maximum<<",\"block_threads\":"<<backend.worker_threads()<<"}\n"<<std::flush;
 std::string line,last_blob;unsigned last_line=~0U;Prepared prepared{};
 while(std::getline(std::cin,line)) {
  if(line=="QUIT")return;
  std::istringstream in(line);std::string op,blob,start_text,count_text,threshold_text,extra;
  if(!(in>>op>>blob>>start_text>>count_text>>threshold_text)||op!="SCAN"||blob.size()!=192||(in>>extra))throw std::runtime_error("malformed worker command");
  uint32_t words[24]{};
  auto nibble=[](char c)->unsigned{if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;throw std::runtime_error("invalid job hex");};
  for(int i=0;i<96;++i)words[i/4]|=(nibble(blob[i*2])*16+nibble(blob[i*2+1]))<<(8*(i%4));
  auto start=number(start_text.c_str()),count=number(count_text.c_str()),threshold=number(threshold_text.c_str());
  if(start>0xffffffffULL||!count||count>maximum||start+count>1ULL<<32||(start>>27)!=((start+count-1)>>27))throw std::runtime_error("invalid worker counter range");
  if(last_blob!=blob||last_line!=(start>>27)){prepared=prepare(words,start,threshold);last_blob=blob;last_line=start>>27;}else prepared.threshold=threshold;
  backend.prepare_job(prepared);backend.reset();ck(cudaEventRecord(begin.e));backend.launch(start,count,backend.worker_threads());ck(cudaEventRecord(end.e));ck(cudaEventSynchronize(end.e));float ms;ck(cudaEventElapsedTime(&ms,begin.e,end.e));std::vector<uint32_t>candidates;bool recovered=backend.collect(candidates);auto size=candidates.size();
  std::cout<<"{\"start\":"<<start<<",\"count\":"<<count<<",\"kernel_ms\":"<<ms<<",\"overflow_recovered\":"<<(recovered?"true":"false")<<",\"candidates\":[";
  for(size_t i=0;i<candidates.size();++i){uint32_t mapped[24];unsigned char digest[64],nonce[64];qtc::map_nonce(words,candidates[i],mapped);qtc::hash_words(mapped,digest);if(qtc::prefix(digest)>threshold)throw std::runtime_error("worker candidate failed full host hash");
   for(int j=0;j<64;++j)nonce[j]=mapped[8+j/4]>>(8*(j%4));
   if(i)std::cout<<',';std::cout<<"{\"counter\":"<<candidates[i]<<",\"nonce\":\""<<hex_bytes(nonce,64)<<"\",\"digest\":\""<<hex_bytes(digest,64)<<"\"}";
  }
  std::cout<<"]}\n"<<std::flush;
 }
}
static int network_cli(int argc,char **argv) {
 std::string algorithm;std::vector<std::string> args;
 for(int i=1;i<argc;++i){std::string a=argv[i];if(a=="--algorithm"){if(++i>=argc)throw std::runtime_error("--algorithm requires a value");algorithm=argv[i];}else if(a!="--disable-cpu")args.push_back(a);}
 if(algorithm!="quantus"&&algorithm!="pearlhash")throw std::runtime_error("kaetech: --algorithm must be quantus or pearlhash");
 std::string controller=algorithm=="quantus"?"mine_qtc.py":"mine_prl.py";
 auto exe=std::filesystem::canonical("/proc/self/exe");std::filesystem::path script;
 for(auto base:{exe.parent_path(),exe.parent_path().parent_path(),exe.parent_path().parent_path().parent_path()}){
  auto candidate=base/"scripts"/controller;if(std::filesystem::is_regular_file(candidate)){script=candidate;break;}
 }
 if(script.empty())throw std::runtime_error("kaetech: network controller missing from package");
 if(algorithm=="quantus"&&!std::getenv("KAETECH_QTC_ASM")&&!std::getenv("QPMINER_QTC_ASM")){
  if(cuInit(0)!=CUDA_SUCCESS)throw std::runtime_error("Cannot initialize NVIDIA CUDA driver");int major=0,minor=0;if(cuDeviceComputeCapability(&major,&minor,0)!=CUDA_SUCCESS)throw std::runtime_error("Cannot query GPU compute capability");
  int sm=major*10+minor;auto root=script.parent_path().parent_path();std::filesystem::path module;
  if(sm==52&&std::filesystem::exists(root/"bin/portable/qtc-ported-sm52.cubin"))module=root/"bin/portable/qtc-ported-sm52.cubin";
  if(sm==61||sm==62)module=root/"kernels/original/quantus/quantus-sm61.cubin";
  if(sm==86){module=exe.parent_path()/"qtc-reassembled.cubin";if(!std::filesystem::exists(module))module=root/"bin/linux-sm86/qtc-reassembled.cubin";}
  if(module.empty()||!std::filesystem::exists(module)){
   const int targets[]={70,75,80,86,89,90,103,120};int chosen=-1;for(int index=0;index<8;index++)if(targets[index]/10==major&&targets[index]<=sm)chosen=index;
   if(chosen>=0){std::ostringstream name;name<<"quantus-"<<(chosen<10?"0":"")<<chosen<<".cubin";module=root/"kernels/original/quantus"/name.str();}
  }
  if(!module.empty()&&std::filesystem::exists(module)){setenv("KAETECH_QTC_ASM",module.c_str(),1);setenv("KAETECH_QTC_AUTOMATIC","1",1);}

 }
 auto deps=script.parent_path().parent_path()/".runtime-deps";if(std::filesystem::is_directory(deps)){std::string path=deps.string();if(auto old=std::getenv("PYTHONPATH"))path+=std::string(":")+old;setenv("PYTHONPATH",path.c_str(),1);}
 std::vector<std::string> command={"python3",script.string()};if(algorithm=="quantus"){command.push_back("--worker");command.push_back(exe.string());}command.insert(command.end(),args.begin(),args.end());
 std::vector<char*> av;for(auto &a:command)av.push_back(a.data());av.push_back(nullptr);execvp("python3",av.data());throw std::runtime_error("kaetech: cannot start python3 controller");
}
int main(int argc,char **argv)try {
 auto brand=miner_name();if(prctl(PR_SET_NAME,brand.c_str(),0,0,0)!=0)throw std::runtime_error("Cannot set miner process name");
 if(argc==2&&std::string(argv[1])=="--gpu-info"){
  if(cuInit(0)!=CUDA_SUCCESS)throw std::runtime_error("CUDA initialization failed");int count=0;if(cuDeviceGetCount(&count)!=CUDA_SUCCESS)throw std::runtime_error("Cannot enumerate CUDA GPUs");
  std::cout<<"{\"devices\":[";for(int i=0;i<count;i++){char name[256]={};int major=0,minor=0;cuDeviceGetName(name,256,i);cuDeviceComputeCapability(&major,&minor,i);if(i)std::cout<<",";std::cout<<"{\"index\":"<<i<<",\"name\":\""<<name<<"\",\"sm\":"<<(major*10+minor)<<"}";}std::cout<<"]}\n";return 0;
 }

 if(argc==2&&std::string(argv[1])=="--version"){std::cout<<brand<<" 0.2.1 (QTC multiarch; PRL native/portable)\n";return 0;}
 if(argc==2&&std::string(argv[1])=="--help"){std::cout<<brand<<" 0.2.1\nusage: "<<brand<<" --algorithm quantus|pearlhash --pool HOST:PORT --wallet ADDRESS.WORKER [--seconds N] [--log FILE]\nLinux x86-64, NVIDIA CUDA; Python 3 controller. Use --seconds 0 for continuous mining.\n";return 0;}
 if(argc>1&&std::string(argv[1]).rfind("--",0)==0)return network_cli(argc,argv);
 if(argc<2)throw std::runtime_error("usage: kaetech selftest | hash INPUT96S OUTPUT64S | scan JOB96 START COUNT THRESHOLD [BLOCK] | bench JOB96 START COUNT THRESHOLD [BLOCK] [REPEATS]");
 std::string mode=argv[1];
 if(mode=="selftest"){selftest();return 0;}
 if(mode=="worker"){if(argc!=2)throw std::runtime_error("worker takes no arguments");worker();return 0;}
 if(mode=="hash") {
  if(argc!=4)throw std::runtime_error("hash requires input and output paths");auto input=read_file(argv[2]);if(input.empty()||input.size()%96||input.size()/96>1<<20)throw std::runtime_error("input must contain 1..1048576 records of 96 bytes");
  unsigned count=input.size()/96;Device<uint32_t>di(count*24);Device<unsigned char>out(count*64);ck(cudaMemcpy(di.p,input.data(),input.size(),cudaMemcpyHostToDevice));hashes<<<(count+127)/128,128>>>(di.p,out.p,count);ck(cudaGetLastError());std::vector<unsigned char>r(count*64);ck(cudaMemcpy(r.data(),out.p,r.size(),cudaMemcpyDeviceToHost));write_file(argv[3],r);std::cout<<"{\"hashes\":"<<count<<"}\n";return 0;
 }
 if(mode=="precompute") {
  if(argc!=6)throw std::runtime_error("precompute requires JOB96 START THRESHOLD OUT120");
  auto data=read_file(argv[2]);if(data.size()!=96)throw std::runtime_error("job must contain 96 bytes");
  auto counter=number(argv[3]),target=number(argv[4]);if(counter>0xffffffffULL)throw std::runtime_error("counter exceeds uint32");
  uint32_t words[24]{};for(int i=0;i<96;++i)words[i/4]|=uint32_t(data[i])<<(8*(i%4));
  auto value=prepare(words,counter,target);const auto *bytes=reinterpret_cast<const unsigned char*>(&value);
  write_file(argv[5],std::vector<unsigned char>(bytes,bytes+sizeof(value)));std::cout<<"{\"job_bytes\":120}\n";return 0;
 }
 if(mode!="scan"&&mode!="bench")throw std::runtime_error("unknown mode");
 if(argc<6||argc>8)throw std::runtime_error("scan/bench requires JOB START COUNT THRESHOLD [BLOCK] [REPEATS]");
 auto input=read_file(argv[2]);if(input.size()!=96)throw std::runtime_error("job must contain 96 bytes");
 auto start64=number(argv[3]),count64=number(argv[4]),threshold=number(argv[5]);unsigned block=argc>6?number(argv[6]):128,repeats=argc>7?number(argv[7]):1;
 if(start64>0xffffffffULL||!count64||count64>1<<24||start64+count64>1ULL<<32||!block||block>1024||block%32||!repeats||repeats>10000)throw std::runtime_error("invalid range/block/repeats");
 if((start64>>27)!=((start64+count64-1)>>27))throw std::runtime_error("dispatch crosses nonce line; split at 2^27");
 uint32_t words[24];for(int i=0;i<24;++i){words[i]=0;for(int b=0;b<4;++b)words[i]|=uint32_t(input[i*4+b])<<(8*b);}
 auto p=prepare(words,start64,threshold);Device<uint32_t>hits(count64),total(1);Event begin,end;std::vector<float>times;QTCScanBackend backend(hits.p,total.p);backend.prepare_job(p);
 for(unsigned r=0;r<=repeats;++r){backend.reset();ck(cudaEventRecord(begin.e));backend.launch(start64,count64,block);ck(cudaEventRecord(end.e));ck(cudaEventSynchronize(end.e));float ms;ck(cudaEventElapsedTime(&ms,begin.e,end.e));if(r)times.push_back(ms);}
 std::vector<uint32_t>candidates;bool recovered=backend.collect(candidates);auto size=candidates.size();std::sort(candidates.begin(),candidates.end());
 // Always verify returned candidates with full host hashing using uint128 field multiplication.
 for(auto c:candidates){uint32_t mapped[24];unsigned char digest[64];qtc::map_nonce(words,c,mapped);qtc::hash_words(mapped,digest);if(qtc::prefix(digest)>threshold)throw std::runtime_error("GPU candidate failed host verification");}
 std::sort(times.begin(),times.end());float median=times[times.size()/2];cudaDeviceProp prop;ck(cudaGetDeviceProperties(&prop,0));
 std::cout<<"{\"mode\":\""<<mode<<"\",\"backend\":\""<<backend.name()<<"\",\"overflow_recovered\":"<<(recovered?"true":"false")<<",\"start\":"<<start64<<",\"count\":"<<count64<<",\"hits\":"<<size<<",\"kernel_median_ms\":"<<median<<",\"kernel_hashes_s\":"<<count64*1000.0/median<<",\"block\":"<<block<<",\"repeats\":"<<repeats<<",\"host_verified\":true,\"counters\":[";
 for(size_t i=0;i<candidates.size();++i){if(i)std::cout<<',';std::cout<<candidates[i];}std::cout<<"]}\n";
 return 0;
}catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}
