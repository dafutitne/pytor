/* Independent keyed BLAKE3 CV implementation for PRL certificate auditing.
 * The chunk counter is the absolute Merkle leaf index, not an XOF counter.
 * No GPU, network, allocation, or external library dependencies.
 */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
static const uint32_t iv[4]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a};
static const unsigned perm[16]={2,6,3,10,7,0,4,13,1,11,12,5,9,14,15,8};
static uint32_t rd(const unsigned char *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void wr(unsigned char *p,uint32_t x){for(unsigned i=0;i<4;i++)p[i]=(unsigned char)(x>>(8*i));}
static uint32_t rot(uint32_t x,unsigned n){return x>>n|x<<(32-n);}
static void g(uint32_t *s,unsigned a,unsigned b,unsigned c,unsigned d,uint32_t x,uint32_t y){
 s[a]+=s[b]+x;s[d]=rot(s[d]^s[a],16);s[c]+=s[d];s[b]=rot(s[b]^s[c],12);
 s[a]+=s[b]+y;s[d]=rot(s[d]^s[a],8);s[c]+=s[d];s[b]=rot(s[b]^s[c],7);
}
static void compress(const uint32_t *cv,const unsigned char *data,uint64_t counter,uint32_t flags,uint32_t *out){
 uint32_t s[16],m[16],next[16];
 memcpy(s,cv,32);memcpy(s+8,iv,16);s[12]=(uint32_t)counter;s[13]=(uint32_t)(counter>>32);s[14]=64;s[15]=flags;
 for(unsigned i=0;i<16;i++)m[i]=rd(data+4*i);
 for(unsigned round=0;round<7;round++){
  g(s,0,4,8,12,m[0],m[1]);g(s,1,5,9,13,m[2],m[3]);g(s,2,6,10,14,m[4],m[5]);g(s,3,7,11,15,m[6],m[7]);
  g(s,0,5,10,15,m[8],m[9]);g(s,1,6,11,12,m[10],m[11]);g(s,2,7,8,13,m[12],m[13]);g(s,3,4,9,14,m[14],m[15]);
  for(unsigned i=0;i<16;i++)next[i]=m[perm[i]];
  memcpy(m,next,64);
 }
 for(unsigned i=0;i<8;i++)out[i]=s[i]^s[i+8];
}
void kaetech_prl_chunk_cvs(const unsigned char *data,const uint64_t *indices,size_t count,const unsigned char *key,unsigned char *out){
 for(size_t i=0;i<count;i++){
  uint32_t cv[8];for(unsigned j=0;j<8;j++)cv[j]=rd(key+4*j);
  for(unsigned block=0;block<16;block++)compress(cv,data+i*1024+block*64,indices[i],16|(block==0?1:0)|(block==15?2:0),cv);
  for(unsigned j=0;j<8;j++)wr(out+i*32+j*4,cv[j]);
 }
}
void kaetech_prl_parent_cv(const unsigned char *children,const unsigned char *key,unsigned root,unsigned char *out){
 uint32_t cv[8],result[8];for(unsigned j=0;j<8;j++)cv[j]=rd(key+4*j);
 compress(cv,children,0,16|4|(root?8:0),result);
 for(unsigned j=0;j<8;j++)wr(out+j*4,result[j]);
}
