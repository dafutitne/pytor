"""Offline PLOG1 decoder. Requires cryptography; never shipped inside the miner."""
from pathlib import Path
import argparse,base64,hashlib,sys
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey,X25519PublicKey
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
MAGIC=b'PYTORLOG\x01';PREFIX=b'PLOG1:';HEADER=len(MAGIC)+8+32+12+1

class Decoder:
 def __init__(self,key):
  if not isinstance(key,X25519PrivateKey):raise ValueError('Expected an X25519 private key')
  self.key=key;self.public=key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
  self.key_id=hashlib.sha256(self.public).digest()[:8];self.cache={}
 def packet(self,data):
  if len(data)<HEADER+16 or not data.startswith(MAGIC):raise ValueError('Invalid encrypted record')
  offset=len(MAGIC)
  if data[offset:offset+8]!=self.key_id:raise ValueError('This record uses a different log key')
  ephemeral=data[offset+8:offset+40];nonce=data[offset+40:offset+52];channel=data[offset+52:offset+53]
  if channel not in (b'O',b'E',b'J',b'P'):raise ValueError('Invalid output channel')
  if ephemeral not in self.cache:
   if len(self.cache)>=256:self.cache.clear()
   shared=self.key.exchange(X25519PublicKey.from_public_bytes(ephemeral))
   key=HKDF(algorithm=hashes.SHA256(),length=32,salt=None,info=b'pytor/log/v1\x00'+self.public+ephemeral).derive(shared)
   self.cache[ephemeral]=ChaCha20Poly1305(key)
  return channel,self.cache[ephemeral].decrypt(nonce,data[HEADER:],data[:HEADER])

def main():
 p=argparse.ArgumentParser(description='Decrypt Pytor logs locally using your private log key')
 p.add_argument('input',nargs='?',default='-',help='Encrypted log file or - for stdin');p.add_argument('--key',type=Path,required=True);p.add_argument('--output',type=Path);p.add_argument('--proof',action='store_true');p.add_argument('--allow-plain',action='store_true',help='Pass through non-PLOG1 lines, e.g. OS loader errors')
 a=p.parse_args();key=serialization.load_pem_private_key(a.key.read_bytes(),password=None);decoder=Decoder(key)
 if a.proof:
  if a.input=='-' or not a.output:p.error('--proof requires input file and --output')
  channel,data=decoder.packet(Path(a.input).read_bytes())
  if channel!=b'P':raise ValueError('Not an encrypted proof')
  with a.output.open('xb') as out:out.write(data)
  return
 source=sys.stdin.buffer if a.input=='-' else Path(a.input).open('rb');output=sys.stdout.buffer if not a.output else a.output.open('xb')
 try:
  for line in source:
   if not line.strip():continue
   if not line.startswith(PREFIX):
    if a.allow_plain:output.write(line);output.flush();continue
    raise ValueError('Plaintext or unsupported input; use --allow-plain only if intended')
   channel,data=decoder.packet(base64.b64decode(line[len(PREFIX):].strip(),validate=True))
   if channel==b'P':raise ValueError('Use --proof for proof records')
   output.write(data if data.endswith(b'\n') else data+b'\n');output.flush()
 finally:
  if source is not sys.stdin.buffer:source.close()
  if output is not sys.stdout.buffer:output.close()
if __name__=='__main__':
 try:main()
 except Exception as error:print('decrypt_logs: authentication/decryption failed ('+type(error).__name__+')',file=sys.stderr);raise SystemExit(1)
