"""Security regression checks for encrypted outputs, not mining/GPU benchmarks."""
from pathlib import Path
import base64,concurrent.futures,hashlib,importlib.util,json,os,subprocess,sys,tempfile,time
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from cryptography.hazmat.primitives import serialization

def run(scripts):
 sys.path.insert(0,str(scripts));import secure_log
 spec=importlib.util.spec_from_file_location('offline_decoder',Path(__file__).with_name('decrypt_logs.py'));dec=importlib.util.module_from_spec(spec);spec.loader.exec_module(dec)
 key=X25519PrivateKey.generate();pub=key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
 writer=secure_log.RecipientWriter(pub);decoder=dec.Decoder(key)
 messages=[b'',b'private wallet worker pool details\n',bytes(range(256))*4096]
 for channel in (b'O',b'E',b'J',b'P'):
  for plain in messages:
   packet=writer.packet(plain,channel);got,data=decoder.packet(packet);assert got==channel and data==plain
 packet=writer.packet(b'sensitive marker',b'J');rejected=0
 for index in range(len(packet)):
  changed=bytearray(packet);changed[index]^=1
  try:decoder.packet(bytes(changed))
  except Exception:rejected+=1
  else:raise AssertionError('Modified encrypted record accepted')
 try:dec.Decoder(X25519PrivateKey.generate()).packet(packet)
 except Exception:pass
 else:raise AssertionError('Wrong private key accepted')
 with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:packets=list(pool.map(lambda i:writer.packet(str(i).encode()),range(2000)))
 nonce_start=len(secure_log.MAGIC)+8+32
 assert len({p[nonce_start:nonce_start+12] for p in packets})==len(packets)
 for i,p in enumerate(packets):assert decoder.packet(p)[1]==str(i).encode()
 with tempfile.TemporaryDirectory() as directory:
  root=Path(directory);(root/'log-public.pem').write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo))
  code='''from pathlib import Path
import sys,os,subprocess,traceback
sys.path.insert(0,sys.argv[1]);import secure_log
secure_log.ROOT=Path(sys.argv[2]);capture=secure_log.Capture().start()
try:
 print('PRIVATE_PYTHON_STDOUT',flush=True)
 os.write(2,b'PRIVATE_NATIVE_STDERR\\n')
 result=subprocess.run([sys.executable,'-c',"import os;print('INTERNAL_PROTOCOL');os.write(2,b'PRIVATE_CHILD_STDERR\\\\n')"],stdout=subprocess.PIPE,stderr=2,check=True)
 assert result.stdout.strip()==b'INTERNAL_PROTOCOL'
 with secure_log.EncryptedTextLog(Path(sys.argv[2])/'events.jsonl') as f:f.write('{"private":"PRIVATE_FILE_EVENT"}\\n')
 path=secure_log.save_proof(Path(sys.argv[2])/'share.proof.bin',b'PRIVATE_PROOF_BYTES');assert path.suffix=='.enc'
 try:raise RuntimeError('PRIVATE_TRACEBACK')
 except RuntimeError:traceback.print_exc()
finally:capture.finish()
'''
  p=subprocess.run([sys.executable,'-c',code,str(scripts),str(root)],capture_output=True,timeout=30,check=True)
  clear=[]
  for stream in [p.stdout,p.stderr]:
   assert b'PRIVATE_' not in stream and b'INTERNAL_PROTOCOL' not in stream
   for line in stream.splitlines():
    assert line.startswith(secure_log.PREFIX),line[:80]
    clear.append(decoder.packet(base64.b64decode(line[len(secure_log.PREFIX):],validate=True))[1])
  restored=b''.join(clear)
  for marker in [b'PRIVATE_PYTHON_STDOUT',b'PRIVATE_NATIVE_STDERR',b'PRIVATE_CHILD_STDERR',b'PRIVATE_TRACEBACK']:assert marker in restored,marker
  event=(root/'events.jsonl').read_bytes();assert b'PRIVATE_' not in event
  assert b'PRIVATE_FILE_EVENT' in decoder.packet(base64.b64decode(event[len(secure_log.PREFIX):]))[1]
  assert not (root/'share.proof.bin').exists()
  assert decoder.packet((root/'share.proof.enc').read_bytes())==(b'P',b'PRIVATE_PROOF_BYTES')
 started=time.perf_counter()
 for i in range(2000):writer.line(b'{"event":"progress","mathex":120,"accepted":3}')
 report={'passed':True,'roundtrips':12,'tamper_rejections':rejected,'concurrent_unique_nonces':2000,'stdout_stderr_native_child_file_proof_and_traceback_encrypted':True,'event_encrypt_mean_us':(time.perf_counter()-started)/2000*1e6,'scope':'CPU crypto/output tests; not a GPU hashrate benchmark'}
 print(json.dumps(report));return report
if __name__=='__main__':run(Path(sys.argv[1]).resolve())
