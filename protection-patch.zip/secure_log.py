"""Recipient-only encrypted application output; private keys are never required here."""
from pathlib import Path
import base64,hashlib,json,os,sys,threading
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey,X25519PublicKey
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

MAGIC=b'PYTORLOG\x01';PREFIX=b'PLOG1:'
ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))
_writer=None;_writer_lock=threading.Lock()

def _derive(shared,recipient,ephemeral):
 return HKDF(algorithm=hashes.SHA256(),length=32,salt=None,info=b'pytor/log/v1\x00'+recipient+ephemeral).derive(shared)

class RecipientWriter:
 def __init__(self,recipient):
  if len(recipient)!=32:raise ValueError('Invalid log recipient')
  self.recipient=recipient;self.key_id=hashlib.sha256(recipient).digest()[:8]
  ephemeral=X25519PrivateKey.generate();self.public=ephemeral.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
  self.cipher=ChaCha20Poly1305(_derive(ephemeral.exchange(X25519PublicKey.from_public_bytes(recipient)),recipient,self.public))
  self.nonce_prefix=os.urandom(4);self.counter=0;self.lock=threading.Lock()
 def packet(self,data,channel=b'J'):
  if channel not in (b'O',b'E',b'J',b'P'):raise ValueError('Invalid output channel')
  with self.lock:
   if self.counter>=1<<64:raise OverflowError('Encrypted log nonce limit reached')
   nonce=self.nonce_prefix+self.counter.to_bytes(8,'big');self.counter+=1
   header=MAGIC+self.key_id+self.public+nonce+channel
   return header+self.cipher.encrypt(nonce,bytes(data),header)
 def line(self,data,channel=b'J'):
  return PREFIX+base64.b64encode(self.packet(data,channel))+b'\n'

def writer():
 global _writer
 with _writer_lock:
  if _writer is None:
   key=serialization.load_pem_public_key((ROOT/'log-public.pem').read_bytes())
   if not isinstance(key,X25519PublicKey):raise ValueError('Expected X25519 log public key')
   _writer=RecipientWriter(key.public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw))
  return _writer

def write_events(path,events,mode='a'):
 with Path(path).open(mode+'b') as output:
  for event in events:output.write(writer().line(json.dumps(event).encode('utf-8')))

class EncryptedTextLog:
 def __init__(self,path,mode='w'):self.output=Path(path).open(mode+'b')
 def write(self,text):
  self.output.write(writer().line(text.encode('utf-8')));return len(text)
 def flush(self):self.output.flush()
 def close(self):self.output.close()
 def __enter__(self):return self
 def __exit__(self,*args):self.close()

def save_proof(path,data):
 path=Path(path).with_suffix('.enc');path.write_bytes(writer().packet(data,b'P'));return path

def _write_all(fd,data):
 view=memoryview(data)
 while view:
  count=os.write(fd,view)
  if count<=0:raise OSError('Output write failed')
  view=view[count:]

class Capture:
 """Capture both OS file descriptors, including native child stderr, without plaintext spools."""
 def __init__(self):self.saved=[];self.threads=[];self.started=False
 def start(self):
  writer() # Validate crypto/key before redirecting any output.
  sys.stdout.flush();sys.stderr.flush()
  try:
   for fd,channel in ((1,b'O'),(2,b'E')):
    saved=os.dup(fd);read_fd,write_fd=os.pipe();self.saved.append((fd,saved))
    os.dup2(write_fd,fd);os.close(write_fd)
    thread=threading.Thread(target=self._drain,args=(read_fd,saved,channel),daemon=True);thread.start();self.threads.append(thread)
   self.started=True;return self
  except BaseException:
   self.finish();raise
 def _drain(self,read_fd,saved,channel):
  try:
   buffer=b''
   while True:
    chunk=os.read(read_fd,65536)
    if not chunk:break
    buffer+=chunk
    while b'\n' in buffer:
     line,buffer=buffer.split(b'\n',1);_write_all(saved,writer().line(line+b'\n',channel))
    if len(buffer)>1048576:
     _write_all(saved,writer().line(buffer,channel));buffer=b''
   if buffer:_write_all(saved,writer().line(buffer,channel))
  except BaseException:
   # Never fall back to emitting an unencrypted log record.
   try:_write_all(saved,b'pytor: encrypted output failed\n')
   finally:os._exit(1)
  finally:os.close(read_fd)
 def finish(self):
  sys.stdout.flush();sys.stderr.flush()
  for fd,saved in self.saved:os.dup2(saved,fd)
  for thread in self.threads:thread.join(timeout=5)
  if any(t.is_alive() for t in self.threads):
   # Live children holding inherited descriptors may delay EOF. Keep saved handles valid.
   self.started=False;return
  for _,saved in self.saved:os.close(saved)
  self.saved=[];self.threads=[];self.started=False
