from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).resolve().parent;p=r/'payload'
shutil.copytree(r/'base-payload',p,dirs_exist_ok=True)
s=p/'scripts'
shutil.copy2(r/'secure_log.py',s/'secure_log.py')
prl=(s/'mine_prl.py').read_text(encoding='utf-8')
prl=prl.replace('from prl_engine import Engine','from prl_engine import Engine\nfrom secure_log import EncryptedTextLog,save_proof')
assert "output=logfile.open('w')" in prl
prl=prl.replace("output=logfile.open('w')","output=EncryptedTextLog(logfile,'w')")
old="proofpath=logfile.with_name(logfile.stem+f'-share-{request_id}.proof.bin');proofpath.write_bytes(proof)"
assert old in prl;prl=prl.replace(old,"proofpath=save_proof(logfile.with_name(logfile.stem+f'-share-{request_id}.proof.bin'),proof)")
old="{path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in [Path(__file__),root/'scripts/prl_engine.py',root/'scripts/prl_protocol.py']}"
assert old in prl;prl=prl.replace(old,"{name:hashlib.sha256(Path(sys.modules[name].__file__).read_bytes()).hexdigest() for name in ['mine_prl','prl_engine','prl_protocol']}")
(s/'mine_prl.py').write_text(prl,encoding='utf-8')
qtc=(s/'mine_qtc.py').read_text(encoding='utf-8').replace('from branding import miner_name,agent,set_process_name,default_log','from branding import miner_name,agent,set_process_name,default_log\nfrom secure_log import write_events')
old="with Path(args.log).open('a') as output:output.write(''.join(json.dumps(e)+'\\n' for e in events))"
assert old in qtc;qtc=qtc.replace(old,"write_events(args.log,events);args._history.extend(events)")
old="records=[json.loads(line) for line in Path(args.log).read_text().splitlines() if line]"
assert old in qtc;qtc=qtc.replace(old,"records=args._history")
qtc=qtc.replace("Path(args.log).write_text('')","Path(args.log).write_bytes(b'');args._history=[]")
qtc=qtc.replace('bufsize=1,env=worker_env)','bufsize=1,env=worker_env,stderr=sys.stderr)')
old="with Path(args.log).open('a') as output:output.write(json.dumps(event)+'\\n')"
assert qtc.count(old)==2;qtc=qtc.replace(old,"write_events(args.log,[event]);args._history.append(event)")
(s/'mine_qtc.py').write_text(qtc,encoding='utf-8')
entry=(s/'standalone_entry.py').read_text(encoding='utf-8').replace('pytor-linux-jammy3-label','pytor-linux-protect1')
entry=entry.replace('sizes=(2,4,8) if batched and e.device[\'sm\']==120 else ((8,16,32) if batched else (1,1))','sizes=[2,4,8] if batched and e.device[\'sm\']==120 else ([8,16,32] if batched else [1,1])')
entry=entry.replace("runpy.run_path(str(ROOT/'tests/check_qtc_bn_share.py'),run_name='__main__');return","import qtc_selfcheck;return")
entry=entry.replace("runpy.run_path(sys.argv[0],run_name='__main__');return","import importlib\n  importlib.import_module(script[:-3]).main();return")
entry=entry.replace("os.execve(str(core),[str(core),*args],native_environment())","import subprocess\n result=subprocess.run([str(core),*args],env=native_environment());raise SystemExit(result.returncode)")
assert "runpy.run_path" not in entry
a=entry.index("if __name__=='__main__':")
entry=entry[:a]+'''
def start():
 # Internal worker stdout is a pipe protocol consumed by the parent controller.
 # Its stderr remains inherited from the parent's encrypted FD capture.
 if sys.argv[1:]==['--qtc-driver-worker']:
  main();return
 if not sys.argv[1:] or sys.argv[1:] in (['--help'],['--version'],['--verify-bundle']):
  main();return
 from secure_log import Capture
 try:capture=Capture().start()
 except Exception:
  print('pytor: cannot initialize encrypted logging',file=sys.stderr);raise SystemExit(1)
 try:
  verify_payload()
  main()
 except KeyboardInterrupt:raise SystemExit(130)
 except Exception:
  import traceback
  traceback.print_exc();raise SystemExit(1)
 finally:capture.finish()
'''
(s/'protected_app.py').write_text(entry,encoding='utf-8')
for name in ['quantus_reference.py','qtc_nonce_mapping.py']:shutil.copy2(p/'tests/oracles'/name,s/name)
reference=(s/'quantus_reference.py').read_text(encoding='utf-8')
reference=reference.replace('a, b, c, d = state[j:j+4]','a = state[j]; b = state[j+1]; c = state[j+2]; d = state[j+3]')
(s/'quantus_reference.py').write_text(reference,encoding='utf-8')
shutil.copy2(p/'tests/check_qtc_bn_share.py',s/'qtc_selfcheck.py')
# This file intentionally contains only the loader; the application is compiled.
(r/'loader.py').write_text('''import sys
from pathlib import Path
sys.path.insert(0,str(Path(getattr(sys,"_MEIPASS",Path(__file__).resolve().parent))/"scripts"))
try:
 from protected_app import start
except Exception:
 print("pytor: protected runtime could not be loaded",file=sys.stderr)
 raise SystemExit(1)
start()
''')
print('prepared protected source payload')
